#include <iostream>
using namespace std;
int main() {
	cout << "K  K  FFFF" << endl;
	cout << "K K   F" << endl;
	cout << "KK    FFF" << endl;
	cout << "K K   F" << endl;
	cout << "K  K  F" << endl;
	return 0;
}