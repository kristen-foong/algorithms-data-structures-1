#include <iostream>
using namespace std;
int main() {
	string q;
	cout << "Hello, what's your name?" << endl;
	cin >> q;
	cout << "Welcome " << q << ". Ready Player One." << endl;
	return 0;
}
