#include <cstdlib>
#include <climits>
#include <iostream>
#include "MemoryQueue.h"

using namespace std;

MemoryQueue::MemoryQueue(){
   Node* dummy = new Node;
   dummy->next = dummy;
   dummy->prev = dummy;
   dummy->space = INT_MIN;
   dummy->id = INT_MIN;
}

MemoryQueue::MemoryQueue(int c){
   capacity = c;
   total = 0;
   MemoryQueue();
}

void MemoryQueue::enqueue(int s, int i){
   cout << "enqueueing" << endl;
   if((total + s) > capacity){
      //cout << "enqueueing 1" << endl;
      dequeue();
   }else if(s > capacity){
      //cout << "enqueueing 2" << endl;
      cout << "Space is greater than capacity. Cannot enqueue." << endl;
      dequeue();
   }else if(dummy->id == INT_MIN){
      //cout << "enqueueing 3" << endl;
      Node* p = new Node;
      p->next = dummy;
      p->prev = dummy->prev;
      dummy->prev->next = p;
      dummy->prev = p;
      p->id = i;
      p->space = s;
      total += s;
   }
}

void MemoryQueue::dequeue(){
   if(isEmpty()){
      cout << "Cannot dequeue. Queue is empty." << endl;
      exit(1);
   }
   Node* igotthis = dummy->next;
   igotthis -> next -> prev = dummy; 
   dummy -> next = igotthis -> next;
   int id = igotthis->id;
   cout << "Job " << id << " removed." << endl;
   delete igotthis;
}

void MemoryQueue::showState(){
   int sc = 0;
   Node* current = dummy -> next;
   while(current->id != INT_MIN){
      int id = current->id;
      int space = current->space;
      cout << id << ":" << space << endl;
      sc += space;
      current = current->next;
   }
   cout << "Total space remaining: " << sc << endl;
   cout << "--------------------" << endl;
}